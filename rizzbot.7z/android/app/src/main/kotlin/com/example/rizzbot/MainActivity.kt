package com.example.rizzbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
